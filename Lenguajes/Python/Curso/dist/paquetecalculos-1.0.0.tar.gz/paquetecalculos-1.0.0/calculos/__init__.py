#una vez creado este archivo, 
#python sabe que lo que se almacena dentro del directorio es parte de un paquete

#el contenido de este archivo puede estar vacio

