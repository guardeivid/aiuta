def sumar(n1, n2):
	print(" El resultado de la suma es: " + str(n1+n2))

def restar(n1, n2):
	print(" El resultado de la resta es: " + str(n1-n2))

def multiplicar(n1, n2):
	print(" El resultado de la multiplicacion es: " + str(n1*n2))

def dividir(dividendo, divisor):
	print(" El resultado de la division es: " + str(dividendo/divisor))

def potencia(base, exp):
	print(" El resultado de la potencia es: " + str(base**exp))

def redondear(n1):
	print(" El resultado de redondear es: " + str(round(n1)))
