def potencia(base, exp):
	print(" El resultado de la potencia es: " + str(base**exp))

def redondear(n1):
	print(" El resultado de redondear es: " + str(round(n1)))